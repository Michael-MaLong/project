# coding=utf-8

from django.conf.urls import url
from modules.common import views

urlpatterns = [
    url(r'index$', views.IndexView.as_view(), name='index'),
]
