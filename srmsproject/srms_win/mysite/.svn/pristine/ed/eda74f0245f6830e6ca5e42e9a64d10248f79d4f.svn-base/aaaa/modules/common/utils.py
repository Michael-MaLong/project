# coding=utf-8
import traceback
from modules.contentinfo.models import Contentinfo
from modules.serverinfo.models import Serverinfo
from mysite import settings
import os

# 获取动态查询条件
def get_kwargs(param):
    """组装查询条件集合
    :param param:
    :return:
    """
    kwargs = dict()
    try:
        [kwargs.update({query_field: param}) for query_field, param in param.items() if param]
    except:
        traceback.print_exc()
    return kwargs


#
def initServerContent():
    pass

    return


# 初始化服务器资源信息
def initServerContent():
    pass

    return


#上传文件
def uploadfile(request, requestfname, fname):
    try:
        os.makedirs(os.path.split(fname)[0])
    except:
        pass
    f = request.FILES[requestfname]
    file = open(fname, 'wb+')
    for chunk in f.chunks():
        file.write(chunk)
    file.close()


#文件升级
def updatefile(request, requestfname, fname):
    pass


#目录升级
def updatedir(request, requestfname, fname):
    pass


